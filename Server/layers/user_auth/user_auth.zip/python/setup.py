from setuptools import setup, find_packages

setup(
    name="lambda-layers-user_auth",
    version="0.1.0",
    packages=find_packages(),
    py_modules=["user_auth"]
)